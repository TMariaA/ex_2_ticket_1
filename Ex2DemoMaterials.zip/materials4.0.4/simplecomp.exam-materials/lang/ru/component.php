<?
$MESS["SIMPLECOMP_EXAM2_IBLOCK_MODULE_NONE"] = "Модуль Информационных блоков не установлен";
?>