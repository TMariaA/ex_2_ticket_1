<?
$MESS["SIMPLECOMP_EXAM2_CAT_IBLOCK_ID"] = "ID инфоблока с каталогом товаров";
?>