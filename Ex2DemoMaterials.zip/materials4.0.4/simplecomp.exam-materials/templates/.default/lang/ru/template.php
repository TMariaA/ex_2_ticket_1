<?
$MESS["SIMPLECOMP_EXAM2_CAT_TITLE"] = "Каталог";
?>