<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetTitle("about");
?>Contact our specialists and get professional advice on the creation and purchase of furniture (from design, development of technical specifications to delivery of furniture to your home).<br>
 <br>
 You can contact us by phone, by e-mail or arrange a meeting in our office. We will be happy to help you and answer all your questions.<br>
 <br>
 Phones<br>
 <br>
 Phone fax:<br>
 (495) 212-85-06<br>
 Telephones:<br>
 (495) 212-85-07<br>
 (495) 212-85-08<br>
 Email address<br>
 <br>
 <a href="mailto:Info@example.ru">Info@example.ru</a> - general questions<br>
 <a href="mailto:Sales@example.ru">Sales@example.ru</a> - purchase of products<br>
 <a href="mailto:Marketing@example.ru">Marketing@example.ru</a> - marketing / events / PR<br><?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>