<?
$MESS["MENU_TREE_NAME"] = "Нижнє меню";
$MESS["MENU_TREE_DESC"] = "Нижнє меню";
?>