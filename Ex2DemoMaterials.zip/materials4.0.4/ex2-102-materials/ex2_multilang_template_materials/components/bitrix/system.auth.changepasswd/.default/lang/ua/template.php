<?
$MESS["AUTH_CHANGE_PASSWORD"] = "Зміна паролю";
$MESS["AUTH_LOGIN"] = "Логін";
$MESS["AUTH_CHECKWORD"] = "Контрольний рядок";
$MESS["AUTH_NEW_PASSWORD"] = "Новий пароль";
$MESS["AUTH_NEW_PASSWORD_CONFIRM"] = "Підтвердження паролю";
$MESS["AUTH_CHANGE"] = "Змінити пароль";
$MESS["AUTH_REQ"] = "Обов'язкові поля";
$MESS["AUTH_AUTH"] = "Авторизація";
$MESS["AUTH_NEW_PASSWORD_REQ"] = "Новий пароль";
?>