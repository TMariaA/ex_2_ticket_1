<?
$MESS["AUTH_LOGIN_BUTTON"] = "Авторизуватися";
$MESS["AUTH_CLOSE_WINDOW"] = "Закрити";
$MESS["AUTH_LOGOUT_BUTTON"] = "Вийти";
$MESS["AUTH_REMEMBER_ME"] = "Запам'ятати мене на цьому комп'ютері";
$MESS["AUTH_FORGOT_PASSWORD_2"] = "Забули свій пароль?";
$MESS["AUTH_REGISTER"] = "Реєстрація";
$MESS["AUTH_LOGIN"] = "Логін";
$MESS["AUTH_PASSWORD"] = "Пароль";
$MESS["AUTH_PROFILE"] = "Мій профіль";
?>