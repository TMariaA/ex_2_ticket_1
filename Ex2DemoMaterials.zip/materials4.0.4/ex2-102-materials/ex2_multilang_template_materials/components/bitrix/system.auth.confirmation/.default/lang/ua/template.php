<?
$MESS["CT_BSAC_CONFIRM"] = "Підтвердити";
$MESS["CT_BSAC_LOGIN"] = "Логін";
$MESS["CT_BSAC_CONFIRM_CODE"] = "Код підтвердження";
?>