<?
$MESS["FOOTER_DISIGN"] = "Powered by <a href=\"http://www.bitrixsoft.com\" title=\"Powered by &laquo;Bitrix Site Manager&raquo;\">&laquo;Bitrix Site Manager&raquo;</a>";
?>