<?
$MESS["FOOTER_DISIGN"] = '<a href="http://www.1c-bitrix.ru" title="Работает на &laquo;1С-Битрикс: Управление сайтом&raquo;">Работает на &laquo;1С-Битрикс: Управление сайтом&raquo;</a>';
?>