<?
$MESS["CFST_TEMPLATE_NAME"] = "ex2-102 материалы";
$MESS["CFST_TEMPLATE_DESC"] = "материалы для задания ex2-102";
?>