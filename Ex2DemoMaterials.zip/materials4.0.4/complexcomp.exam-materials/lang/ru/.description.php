<?
$MESS ['IBLOCK_PHOTO_NAME'] = "Мой комплексный компонент (материалы к экзамену)";
$MESS ['IBLOCK_PHOTO_SECTION'] = "Экзамен №2";
$MESS ['IBLOCK_PHOTO_DESCRIPTION'] = "Полная фотогалерея";
$MESS ['T_IBLOCK_DESC_PHOTO'] = "Фотогалерея";
?>