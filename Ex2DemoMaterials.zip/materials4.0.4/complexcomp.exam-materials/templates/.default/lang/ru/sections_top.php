<?
$MESS["EXAM_TEXT_LINK_CP_PHOTO"] = "Страница экзамена:";
